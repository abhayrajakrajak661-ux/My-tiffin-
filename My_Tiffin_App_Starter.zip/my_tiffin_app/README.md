# My Tiffin — शुरुआती PWA

## इसमें क्या है
- Responsive order form for Android/iPhone browsers
- Regular ₹90 / Special ₹130 demo prices
- Daily, 7-day and 30-day selection
- Quantity and total calculation
- WhatsApp order handoff
- Basic installable PWA files

## WhatsApp नंबर सेट करना
1. `index.html` को text/code editor में खोलें।
2. `const SELLER_WHATSAPP = "91XXXXXXXXXX";` खोजें।
3. इसे अपने बिज़नेस WhatsApp नंबर से बदलें। भारत का देश कोड 91 लगाएँ और केवल अंक लिखें।
4. फाइल सेव करें।

## चलाने का तरीका
- `index.html` को ब्राउज़र में खोलकर फॉर्म और कीमत की गणना टेस्ट कर सकते हैं।
- PWA install और offline cache के लिए इसे HTTPS वाली static hosting पर डालना होगा। Hosting provider की free tier की शर्तें बदल सकती हैं।
- फिर Android Chrome में menu → Add to Home screen / Install app देखें।
- iPhone Safari में Share → Add to Home Screen देखें।
- WhatsApp ऑर्डर खोलने के लिए नेटवर्क और WhatsApp/WhatsApp Web की उपलब्धता जरूरी है।

## अभी क्या नहीं है
- ऑर्डर डेटाबेस या ऑटोमैटिक ऑर्डर हिस्ट्री
- एडमिन लॉगिन / किचन डैशबोर्ड
- ऑनलाइन पेमेंट, डिलीवरी ट्रैकिंग, पुश नोटिफिकेशन
- App Store / Play Store पर प्रकाशित native app

## सुरक्षा और वास्तविक उपयोग
यह शुरुआती demo है। सार्वजनिक रूप से उपयोग करने से पहले अपने वास्तविक मेनू, कीमत, डिलीवरी क्षेत्र, गोपनीयता सूचना और WhatsApp नंबर की पुष्टि करें। ग्राहक का नाम, फोन और पता संवेदनशील जानकारी है; इसे सार्वजनिक शीट या अनधिकृत जगह पर न रखें।
